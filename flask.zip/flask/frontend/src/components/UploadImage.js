// UploadImage.js

import React, { useState } from 'react';
import axios from 'axios';

const UploadImage = () => {
    const [image, setImage] = useState(null);
    const [uploadStatus, setUploadStatus] = useState('');

    const handleImageUpload = async () => {
        try {
            const formData = new FormData();
            formData.append('image', image);

            const response = await axios.post('http://localhost:5000/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            setUploadStatus(response.data.message);
            // Clear the input after successful upload
            setImage(null);
        } catch (error) {
            console.error('Error uploading image:', error);
        }
    };

    return (
        <div>
            <h2>Upload Image</h2>
            <input type="file" onChange={(e) => setImage(e.target.files[0])} />
            <button onClick={handleImageUpload}>Upload Image</button>
            {uploadStatus && <p>{uploadStatus}</p>}
            <img src="/welcome.png" alt="Welcome" />
        </div>
    );
};

export default UploadImage;
