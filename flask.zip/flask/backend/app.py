# app.py

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import base64
import pytesseract

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///images.db'
db = SQLAlchemy(app)

class Image(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    image_data = db.Column(db.Text)
    extracted_text = db.Column(db.Text)
    bold_words = db.Column(db.Text)

# API endpoint for image upload and text extraction
@app.route('/upload', methods=['POST'])
def upload_image():
    image_file = request.files['image']
    image_data = base64.b64encode(image_file.read()).decode('utf-8')
    
    # Perform OCR to extract text from the image
    extracted_text = pytesseract.image_to_string(image_file)
    
    # Extract bold words from the extracted text
    bold_words = extract_bold_words(extracted_text)
    
    # Save data to the database
    new_image = Image(image_data=image_data, extracted_text=extracted_text, bold_words=bold_words)
    db.session.add(new_image)
    db.session.commit()
    
    return jsonify({'message': 'Image uploaded successfully'})

# Function to extract bold words from text
def extract_bold_words(text):
    
    # This is just a placeholder
    bold_words = [word for word in text.split() if word.isupper()]
    return ' '.join(bold_words)

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
